package com.example.vinothshanmugam.democamera;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.VideoView;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main2Activity extends AppCompatActivity {

    private Button mRecordView, mPlayView ;
    private VideoView mVideoView;
    private int ACTIVITY_START_CAMERA_APP=0;
    File videoFile = null;
    private String mCurrentvideoPath="";
    Uri videoURI=null;
    private Button btnstart;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        mRecordView = (Button) findViewById(R.id.recordButton);
        mPlayView = (Button) findViewById(R.id.playButton);
        mVideoView = (VideoView) findViewById(R.id.VideoView);
        btnstart = (Button) findViewById(R.id.emojibutton);


        mRecordView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                captureVideo();

                //Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
                //startActivityForResult(intent, ACTIVITY_START_CAMERA_APP);
            }
        });

        mPlayView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    mVideoView.start();
                    }
        });

        btnstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity();

            }
        });
    }

    private void captureVideo(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[] { Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE }, 0);
        }
        else
        {
            Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);

            if (takeVideoIntent.resolveActivity(getPackageManager()) != null) {
                // Create the File where the photo should go
                try {

                    videoFile = createVideoFile();
                    displayMessage(getBaseContext(),videoFile.getAbsolutePath());
                    Log.i("Vinoth VK",videoFile.getAbsolutePath());

                    // Continue only if the File was successfully created
                    if (videoFile != null) {
                        Uri videoURI = FileProvider.getUriForFile(this,"com.example.vinothshanmugam.democamera.fileprovider",videoFile);
                        takeVideoIntent.putExtra(MediaStore.EXTRA_OUTPUT, videoURI);
                        startActivityForResult(takeVideoIntent,  ACTIVITY_START_CAMERA_APP);
                    }
                } catch (Exception ex) {
                    // Error occurred while creating the File
                    displayMessage(getBaseContext(),ex.getMessage().toString());
                }
            }else
            {
                displayMessage(getBaseContext(),"Null");
            }
        }
    }

    private File createVideoFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String videoFileName = "VID_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File video = File.createTempFile(
                videoFileName,  /* prefix */
                ".mp4",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentvideoPath = video.getAbsolutePath();
        return video;
    }

    protected void onActivityResult(int requestcode, int resultcode, Intent data){
        if(requestcode == ACTIVITY_START_CAMERA_APP && resultcode == RESULT_OK)
        {
            Uri videUri= data.getData();
            mVideoView.setVideoURI(videUri);
        }
    }


    public void openActivity(){
        Intent intent = new Intent (this, Main3Activity.class);
        startActivity(intent);
    }
    private void displayMessage(Context context, String message)
    {
        Toast.makeText(context,message, Toast.LENGTH_LONG).show();
    }
}
